package com.vmanda.pokemon.Utils;

import android.os.AsyncTask;
import android.util.Log;

import com.vmanda.pokemon.Pokemon;
import com.vmanda.pokemon.PokemonAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NetworkUtils {

    public static class NetworkTask extends AsyncTask<String, Void, List<Pokemon>> {

        @Override
        protected List<Pokemon> doInBackground(String... strings) {
            HttpURLConnection urlConnection;
            String JsonResponse = "";
            try {
                URL url = new URL(strings[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader reader = new BufferedReader(inputStreamReader);
                StringBuilder data = new StringBuilder();
                String line = reader.readLine();
                while (line != null) {
                    data.append(line);
                    line = reader.readLine();
                }
                JsonResponse = data.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return ParseJsonData(JsonResponse);
        }

        protected List<Pokemon> ParseJsonData(String jsonResponse) {

            List<Pokemon> pokemons = new ArrayList<>();

            try {
                JSONObject jsonObject = new JSONObject(jsonResponse);
                if(jsonObject.has("results")) {
                    JSONArray results = jsonObject.getJSONArray("results");
                    for (int i = 0; i < results.length(); i++) {
                        JSONObject jsonPokemon = results.getJSONObject(i);
                        String name = jsonPokemon.getString("name");
                        String url = jsonPokemon.getString("url");
                        url = url.replace("pokemon", "ability");
                        Pokemon pokemon = new Pokemon(name, 0, url);
                        pokemons.add(pokemon);

                    }
                }else if(jsonObject.has("pokemon")) {
                    JSONArray results_pokemon = jsonObject.getJSONArray("pokemon");
                    for (int i = 0; i < results_pokemon.length(); i++) {
                        JSONObject jsonPokemon = results_pokemon.getJSONObject(i);
                        JSONObject jsonPokemon_list = jsonPokemon.getJSONObject("pokemon");
                        String name = jsonPokemon_list.getString("name");
                        String url = jsonPokemon_list.getString("url");
                        url = url.replace("pokemon", "ability");

                        Pokemon pokemon = new Pokemon(name, 0, url);
                        pokemons.add(pokemon);
                    }
                } else {
                    Log.d("NetworkUtils", "no json data");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
           return pokemons;
        }
    }
}
