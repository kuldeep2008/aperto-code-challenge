package com.vmanda.pokemon;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PokemonAdapter extends RecyclerView.Adapter<PokemonAdapter.PokemonViewHolder> {

    List<Pokemon> pokemonList;
    Context mContext;

    public PokemonAdapter(Context context, List<Pokemon> pokemonList) {
        mContext = context;
        this.pokemonList = pokemonList;
    }

    @NonNull
    @Override
    public PokemonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_layout, parent, false);
        return new PokemonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PokemonViewHolder holder, int position) {
        Pokemon pokemon = pokemonList.get(position);
        holder.nameTextView.setText(pokemon.getName());
    }

    @Override
    public int getItemCount() {
        if(pokemonList == null) return 0;
        return pokemonList.size();
    }

    public class PokemonViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView nameTextView;

        public PokemonViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.name_text_view);
            nameTextView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Pokemon pokemon = pokemonList.get(getAdapterPosition());
            Intent intent = new Intent(mContext, PokemonActivity.class);
            intent.putExtra(Intent.EXTRA_TITLE, pokemon.getName());
            intent.putExtra("url", pokemon.getUrl());
            mContext.startActivity(intent);
        }
    }
}
