package com.vmanda.pokemon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import com.vmanda.pokemon.Utils.NetworkUtils;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    public static final String BASE_URL_STRING = "https://pokeapi.co/api/v2/ability/?limit=20";
    public static final String LOAD_MORE_URL_STRING = "https://pokeapi.co/api/v2/ability/?limit=20&offset=";

    List<Pokemon> pokemonList;
    PokemonAdapter adapter;
    RecyclerView recyclerView;
    Boolean isLoading = false;
    int loadingCount = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        setTitle("Main Pokemon");

        pokemonList = new ArrayList<>();
        try {
            pokemonList = new NetworkUtils.NetworkTask().execute(BASE_URL_STRING).get();

            adapter = new PokemonAdapter(this, pokemonList);
            recyclerView.setAdapter(adapter);
            recyclerView.addOnScrollListener(onScrollListener);

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    private RecyclerView.OnScrollListener onScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            if(!isLoading){
                if(linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == pokemonList.size() -1){

                    isLoading = true;
                    try {
                        String url = LOAD_MORE_URL_STRING + loadingCount;
                        pokemonList.addAll(new NetworkUtils.NetworkTask().execute(url).get());
                        loadingCount += 20;
                        isLoading = false;
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }

                }
            }

        }
    };


}
