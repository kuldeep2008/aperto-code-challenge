package com.vmanda.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.vmanda.pokemon.Utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class PokemonActivity extends AppCompatActivity {

    List<Pokemon> pokemonList;
    PokemonAdapter adapter;
    RecyclerView recyclerView;
    TextView emptyTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        emptyTextView = findViewById(R.id.empty_text_view);


        if(getIntent() != null) {

            recyclerView = findViewById(R.id.recycler_view_detail);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            emptyTextView.setVisibility(View.INVISIBLE);

            pokemonList = new ArrayList<>();
            try {
                pokemonList = new NetworkUtils.NetworkTask().execute(getIntent().getStringExtra("url")).get();
                if(pokemonList.size() >0) {
                    adapter = new PokemonAdapter(this, pokemonList);
                    recyclerView.setAdapter(adapter);
                }else {
                    Toast.makeText(this, "No Pokemons for " + getIntent().getStringExtra(Intent.EXTRA_TITLE), Toast.LENGTH_SHORT).show();
                    emptyTextView.setVisibility(View.VISIBLE);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
    }
}
